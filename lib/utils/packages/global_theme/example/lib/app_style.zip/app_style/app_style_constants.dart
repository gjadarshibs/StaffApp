/// Here we add the style constants like common button height, common padding etc.
class AppStyleConstants{
  static const buttonCornerRadious = 10.0;
  static const paddingSize = 10.0;
}